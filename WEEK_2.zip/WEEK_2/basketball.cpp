#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n, d;
    cin >> n >> d;

    vector<int> p(n);
    for (int i = 0; i < n; i++) {
        cin >> p[i];
    }

    sort(p.begin(), p.end());

    int wins = 0;
    int left = 0, right = n - 1;

    while (left <= right) {
        int largestPower = p[right];
        int requiredTeamSize = d / largestPower + 1;

        if (right - left + 1 >= requiredTeamSize) {//if sufficient players are present
        
            left += requiredTeamSize - 1; // decresing size after forming team
            right--;
            wins++;
        } else {
            break;//if  no sufficient players , break.
        }
    }

    cout << wins << endl;

    return 0;
}
